const logininfo  = [
{
    email:"cpaxyz@gmail.com",
    password:"cpaxyz"
},
{
    email:"test@gmail.com",
    password:"test"
}



]
module.exports = logininfo